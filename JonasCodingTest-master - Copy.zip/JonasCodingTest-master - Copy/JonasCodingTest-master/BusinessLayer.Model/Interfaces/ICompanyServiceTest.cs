﻿using BusinessLayer.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Model.Interfaces
{
  public  interface ICompanyServiceTest
    {
        Task<bool> SaveCompanyInfo(CompanyInfo companyInfo);

        Task<CompanyInfo> UpdateCompany(CompanyInfo companyInfo, int id);

        Task<bool> DeleteCompany(int id);

        Task<IEnumerable<CompanyInfo>> GetAllCompanies();

        Task<CompanyInfo> GetCompanyByCode(string companyCode);
    }
}
