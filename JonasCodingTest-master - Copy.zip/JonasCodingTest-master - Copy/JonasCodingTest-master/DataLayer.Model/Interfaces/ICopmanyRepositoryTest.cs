﻿using DataAccessLayer.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Model.Interfaces
{
  public  interface ICopmanyRepositoryTest
    {
       Task<IEnumerable<Company>> GetAll();
        Task< Company> GetByCode(string companyCode);
        Task<bool> SaveCompany(Company company);
    }
}
