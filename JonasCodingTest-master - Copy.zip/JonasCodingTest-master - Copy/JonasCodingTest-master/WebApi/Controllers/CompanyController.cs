﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using AutoMapper;
using BusinessLayer.Model.Interfaces;
using WebApi.Models;
using System.Threading.Tasks;

namespace WebApi.Controllers
{
    public class CompanyController : ApiController
    {
        private readonly ICompanyService _companyService;
        private readonly ICompanyServiceTest _companyServiceTest;
        private readonly IMapper _mapper;

        public CompanyController(ICompanyServiceTest companyServiceTest, IMapper mapper)
        {
            _companyServiceTest = companyServiceTest;
            _mapper = mapper;
        }
        // GET api/<controller>
        public async Task<IActionResult>  GetAll()
        {
            var items = await _companyServiceTest.GetAllCompanies();
            var listCompanines = _mapper.Map<IEnumerable<CompanyDto>>(items);

            return Ok(listCompanines);
        }

        // GET api/<controller>/5
        public async Task<IActionResult> Get(string companyCode)
        {
            var item =await _companyServiceTest.GetCompanyByCode(companyCode);
            var comDto= _mapper.Map<CompanyDto>(item);
            return Ok(comDto);
        }

        // POST api/<controller>
        public async Task<IActionResult> Post([FromBody]CompanyDto company)
        {
            var comInfo=_mapper.Map<CompanyInfo>(company);
            var result = await _companyServiceTest.SaveCompanyInfo(companyCode); ;
            return Ok(result);
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}