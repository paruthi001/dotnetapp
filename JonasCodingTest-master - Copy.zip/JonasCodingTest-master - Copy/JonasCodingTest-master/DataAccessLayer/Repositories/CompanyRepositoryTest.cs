﻿using DataAccessLayer.Model.Interfaces;
using DataAccessLayer.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

using System.Threading.Tasks;

namespace DataAccessLayer.Repositories
{
    public class CompanyRepositoryTest : ICopmanyRepositoryTest
    {
        private readonly IDbWrapper<Company> _companyDbWrapper;

        public CompanyRepositoryTest(IDbWrapper<Company> companyDbWrapper)
        {
            _companyDbWrapper = companyDbWrapper;
        }

        public async Task<IEnumerable<Company>> GetAll()
        {
            return await _companyDbWrapper.FindAllAsync();
        }

        public async Task<Company> GetByCode(string companyCode)
        {
            Expression<Func<Company, bool>> expression = (item) => item.CompanyCode.Equals(companyCode);
            var result= await _companyDbWrapper.FindAsync(expression);
            var company = result.ToList().SingleOrDefault();

            return company;
            
        }

        public async Task<bool> SaveCompany(Company company)
        {
           return await _companyDbWrapper.InsertAsync(company);
        }
    }
}
