﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Model.Models
{
	public class DataEntity
	{
		public string SiteId { get; set; }
		public string CompanyCode { get; set; }
	}
}
